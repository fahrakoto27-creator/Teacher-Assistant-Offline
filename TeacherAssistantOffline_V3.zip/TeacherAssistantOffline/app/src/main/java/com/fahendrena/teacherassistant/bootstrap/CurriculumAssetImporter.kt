package com.fahendrena.teacherassistant.bootstrap

import android.content.Context
import com.fahendrena.teacherassistant.data.AppDatabase
import com.fahendrena.teacherassistant.data.ResourceCategory
import com.fahendrena.teacherassistant.data.ResourceDocument
import com.fahendrena.teacherassistant.data.ResourcePage
import org.json.JSONObject

/**
 * Importe automatiquement, au tout premier lancement, le programme officiel
 * d'Anglais (Programme d'etudes, Repartition Annuelle, Fascicule de
 * Ressources Pedagogiques) pour tous les niveaux du college (6eme a 3eme),
 * depuis les fichiers embarques dans assets/curriculum/.
 *
 * Ces documents sont les documents officiels du Ministere de l'Education
 * Nationale malgache (source publique) et les propres documents de travail
 * de l'enseignant : ils peuvent etre embarques sans probleme de droits
 * d'auteur, contrairement a des ouvrages publies (grammaires, manuels
 * scolaires commerciaux) que l'enseignant doit importer lui-meme depuis
 * "Mes ressources" avec ses propres exemplaires.
 *
 * Cet import est idempotent : il ne s'execute qu'une seule fois (marque
 * par une preference locale), meme si l'enseignant reinstalle ou relance
 * l'application plusieurs fois.
 */
object CurriculumAssetImporter {

    private const val PREFS_NAME = "curriculum_import"
    private const val KEY_IMPORTED = "curriculum_v1_imported"
    private const val ASSETS_DIR = "curriculum"
    private const val MANIFEST_FILE = "manifest.json"

    suspend fun importIfNeeded(context: Context, db: AppDatabase) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_IMPORTED, false)) return

        val manifestText = context.assets.open("$ASSETS_DIR/$MANIFEST_FILE")
            .bufferedReader(Charsets.UTF_8).use { it.readText() }
        val manifest = org.json.JSONArray(manifestText)

        for (i in 0 until manifest.length()) {
            val entry = manifest.getJSONObject(i)
            importDocument(context, db, entry.getString("fichier"))
        }

        prefs.edit().putBoolean(KEY_IMPORTED, true).apply()
    }

    private suspend fun importDocument(context: Context, db: AppDatabase, fileName: String) {
        val jsonText = context.assets.open("$ASSETS_DIR/$fileName")
            .bufferedReader(Charsets.UTF_8).use { it.readText() }
        val json = JSONObject(jsonText)

        val titre = json.getString("titre")
        val categorie = ResourceCategory.valueOf(json.getString("categorie"))
        val niveau = json.getString("niveau")
        val matiere = json.getString("matiere")
        val pagesArray = json.getJSONArray("pages")

        val texteComplet = buildString {
            for (i in 0 until pagesArray.length()) {
                append(pagesArray.getJSONObject(i).getString("texte"))
                append("\n")
            }
        }

        val resource = ResourceDocument(
            titre = titre,
            categorie = categorie,
            niveau = niveau,
            matiere = matiere,
            cheminFichier = "assets://$ASSETS_DIR/$fileName",
            typeFichier = "json",
            texteExtrait = texteComplet
        )
        val resourceId = db.resourceDao().insert(resource)

        val pageEntities = (0 until pagesArray.length()).map { i ->
            val p = pagesArray.getJSONObject(i)
            ResourcePage(
                resourceId = resourceId,
                pageNumber = p.getInt("page"),
                texte = p.getString("texte")
            )
        }
        db.resourcePageDao().insertAll(pageEntities)
    }
}
