package com.fahendrena.teacherassistant.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** Profil de l'enseignant — une seule ligne locale (id fixe = 1). */
@Entity(tableName = "teacher_profile")
data class TeacherProfile(
    @PrimaryKey val id: Int = 1,
    val nom: String = "",
    val etablissement: String = "",
    val matierePrincipale: String = "",
    val anneeScolaire: String = "",
    val langueTravail: String = "Français",
    val dureeHabituelle: Int = 60
)

@Entity(tableName = "school_class")
data class SchoolClass(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nom: String,
    val niveau: String,
    val matiere: String,
    val effectif: Int = 0,
    val anneeScolaire: String = ""
)

enum class ResourceCategory {
    PROGRAMME, REPARTITION, FASCICULE, MANUEL, PERSONNEL
}

@Entity(tableName = "resource_document")
data class ResourceDocument(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val titre: String,
    val categorie: ResourceCategory,
    val niveau: String = "",
    val matiere: String = "",
    val cheminFichier: String,
    val typeFichier: String,
    val texteExtrait: String = "",
    val dateImport: Long = System.currentTimeMillis()
)

enum class PreparationStatut { A_FAIRE, EN_PREPARATION, TERMINEE, A_REVOIR }

@Entity(tableName = "preparation")
data class Preparation(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val classeId: Long,
    val matiere: String,
    val niveau: String,
    val theme: String,
    val titreLecon: String,
    val date: String = "",
    val dureeMinutes: Int = 60,
    val numeroSeance: Int = 1,
    val objectifGeneral: String = "",
    val objectifsSpecifiques: String = "",
    val competences: String = "",
    val prerequis: String = "",
    val materiel: String = "",
    val methodePedagogique: String = "",
    val deroulementJson: String = "",
    val contenuLecon: String = "",
    val vocabulaireJson: String = "",
    val grammaire: String = "",
    val activites: String = "",
    val exercices: String = "",
    val corrige: String = "",
    val evaluation: String = "",
    val devoir: String = "",
    val sourcesJson: String = "[]",
    val statut: PreparationStatut = PreparationStatut.A_FAIRE,
    val dateCreation: Long = System.currentTimeMillis(),
    val dateModification: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "resource_page",
    indices = [Index("resourceId")]
)
data class ResourcePage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val resourceId: Long,
    val pageNumber: Int,
    val texte: String
)
