package com.fahendrena.teacherassistant.data

import androidx.room.TypeConverter

class Converters {
    @TypeConverter
    fun fromResourceCategory(value: ResourceCategory): String = value.name

    @TypeConverter
    fun toResourceCategory(value: String): ResourceCategory = ResourceCategory.valueOf(value)

    @TypeConverter
    fun fromPreparationStatut(value: PreparationStatut): String = value.name

    @TypeConverter
    fun toPreparationStatut(value: String): PreparationStatut = PreparationStatut.valueOf(value)
}
