package com.fahendrena.teacherassistant.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
    entities = [
        TeacherProfile::class, SchoolClass::class, ResourceDocument::class,
        Preparation::class, ResourcePage::class
    ],
    version = 2,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun profileDao(): ProfileDao
    abstract fun classDao(): ClassDao
    abstract fun resourceDao(): ResourceDao
    abstract fun preparationDao(): PreparationDao
    abstract fun resourcePageDao(): ResourcePageDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "teacher_assistant_offline.db"
                )
                    // Projet en développement (V1/V2), pas encore de données réelles
                    // d'enseignant en production : migration destructive acceptable.
                    // À remplacer par de vraies Migration() avant la mise en production.
                    .fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }
    }
}
