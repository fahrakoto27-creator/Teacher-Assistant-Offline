package com.fahendrena.teacherassistant.data

import android.content.Context
import android.net.Uri
import com.fahendrena.teacherassistant.pdf.PdfTextExtractor
import com.fahendrena.teacherassistant.seed.SeedTextChunker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Point d'accès unique aux données locales : profil, classes, ressources,
 * préparations. Toute opération se fait sur le stockage privé de
 * l'application — aucun appel réseau.
 */
class AppRepository(private val context: Context, private val db: AppDatabase) {

    val profile = db.profileDao().observeProfile()
    val classes = db.classDao().observeClasses()
    val resources = db.resourceDao().observeAll()
    val preparations = db.preparationDao().observeAll()

    suspend fun saveProfile(profile: TeacherProfile) = db.profileDao().saveProfile(profile)

    suspend fun addClass(c: SchoolClass) = db.classDao().insert(c)
    suspend fun deleteClass(c: SchoolClass) = db.classDao().delete(c)

    fun preparationById(id: Long) = db.preparationDao().observeById(id)

    suspend fun savePreparation(p: Preparation): Long =
        if (p.id == 0L) db.preparationDao().insert(p) else {
            db.preparationDao().update(p)
            p.id
        }

    suspend fun deletePreparation(p: Preparation) = db.preparationDao().delete(p)
    suspend fun searchPreparations(query: String) = db.preparationDao().search(query)

    suspend fun deleteResource(r: ResourceDocument) {
        withContext(Dispatchers.IO) { File(r.cheminFichier).delete() }
        db.resourceDao().delete(r)
    }

    suspend fun searchResources(query: String) = db.resourceDao().search(query)

    /**
     * Importe une ressource depuis les assets embarques dans l'application
     * (contenus officiels deja fournis par l'enseignant : PE/RAPE/FRP Anglais).
     * Comme il s'agit deja de texte brut, aucune extraction PDF n'est
     * necessaire ; le decoupage en pages suit exactement le meme algorithme
     * que celui utilise a la construction des fiches pre-remplies, afin que
     * les citations (document + page) restent exactes.
     */
    suspend fun importFromAsset(
        assetPath: String,
        titre: String,
        categorie: ResourceCategory,
        niveau: String,
        matiere: String
    ): Long = withContext(Dispatchers.IO) {
        val texte = context.assets.open(assetPath).bufferedReader(Charsets.UTF_8).use { it.readText() }

        val resourcesDir = File(context.filesDir, "resources").apply { mkdirs() }
        val safeName = titre.replace(Regex("[^A-Za-z0-9]+"), "_")
        val destFile = File(resourcesDir, "seed_${safeName}.txt")
        destFile.writeText(texte, Charsets.UTF_8)

        val resource = ResourceDocument(
            titre = titre,
            categorie = categorie,
            niveau = niveau,
            matiere = matiere,
            cheminFichier = destFile.absolutePath,
            typeFichier = "txt",
            texteExtrait = texte
        )
        val resourceId = db.resourceDao().insert(resource)

        val pages = SeedTextChunker.chunk(texte)
        if (pages.isNotEmpty()) {
            val pageEntities = pages.mapIndexed { index, pageText ->
                ResourcePage(resourceId = resourceId, pageNumber = index + 1, texte = pageText)
            }
            db.resourcePageDao().insertAll(pageEntities)
        }

        resourceId
    }

    /**
     * Importe un document choisi par l'enseignant : le copie dans le
     * stockage privé de l'application (donc disponible en permanence, hors
     * ligne) puis en extrait le texte si possible pour la recherche locale.
     */
    suspend fun importResource(
        uri: Uri,
        titre: String,
        categorie: ResourceCategory,
        niveau: String,
        matiere: String
    ): Long = withContext(Dispatchers.IO) {
        val resourcesDir = File(context.filesDir, "resources").apply { mkdirs() }
        val extension = guessExtension(uri)
        val safeName = titre.replace(Regex("[^A-Za-z0-9]+"), "_")
        val destFile = File(resourcesDir, "${System.currentTimeMillis()}_$safeName.$extension")

        context.contentResolver.openInputStream(uri)?.use { input ->
            destFile.outputStream().use { output -> input.copyTo(output) }
        }

        val pages: List<String> = when (extension) {
            "pdf" -> runCatching { PdfTextExtractor.extractPages(context, destFile) }.getOrDefault(emptyList())
            "txt" -> runCatching { listOf(destFile.readText()) }.getOrDefault(emptyList())
            else -> emptyList()
        }
        val texte = pages.joinToString("\n")

        val resource = ResourceDocument(
            titre = titre,
            categorie = categorie,
            niveau = niveau,
            matiere = matiere,
            cheminFichier = destFile.absolutePath,
            typeFichier = extension,
            texteExtrait = texte
        )
        val resourceId = db.resourceDao().insert(resource)

        if (pages.isNotEmpty()) {
            val pageEntities = pages.mapIndexed { index, pageText ->
                ResourcePage(resourceId = resourceId, pageNumber = index + 1, texte = pageText)
            }
            db.resourcePageDao().insertAll(pageEntities)
        }

        resourceId
    }

    private fun guessExtension(uri: Uri): String {
        val type = context.contentResolver.getType(uri) ?: ""
        return when {
            type.contains("pdf") -> "pdf"
            type.contains("wordprocessingml") -> "docx"
            type.contains("text/plain") -> "txt"
            else -> uri.lastPathSegment?.substringAfterLast('.', "dat") ?: "dat"
        }
    }
}
