# Teacher Assistant Offline — V1 + V2 (pédagogie, début)

Application Android native (Kotlin + Jetpack Compose + Room), conçue pour
fonctionner **entièrement hors ligne** après installation, conformément au
cahier des charges.

## Contenu de cette V1

- Interface d'accueil (menu principal)
- Profil enseignant (nom, établissement, matière, année scolaire, langue,
  durée habituelle) — stocké localement
- Gestion des classes (créer / lister / supprimer)
- Import de ressources (PDF, DOCX, TXT) : le fichier est copié dans le
  stockage privé de l'application (donc disponible hors ligne en
  permanence) ; le texte des PDF est extrait localement (PdfBox-Android)
  pour alimenter la recherche
- Recherche locale (dans les ressources importées ET dans les préparations
  déjà créées), aucune requête réseau
- Création de fiches de préparation (objectifs, compétences, prérequis,
  déroulement, contenu de leçon, vocabulaire, grammaire, activités,
  exercices, corrigé, évaluation, devoir)
- Export PDF A4 de la fiche complète (généré localement avec
  `android.graphics.pdf.PdfDocument`, aucune bibliothèque cloud)

Aucune permission INTERNET n'est déclarée dans le manifeste : c'est
volontaire, pour garantir le fonctionnement hors ligne au niveau du
système lui-même.

## Nouveautés V2 (début — génération assistée par les sources)

- **Extraction PDF page par page** (`ResourcePage`) : chaque page importée
  est indexée séparément, ce qui permet de citer précisément un document
  et un numéro de page.
- **`LessonContentGenerator`** : recherche dans les ressources importées en
  respectant la **hiérarchie des sources** du cahier des charges
  (Programme → Répartition → Fascicule → Manuel → Documents personnels) ;
  ne génère jamais d'information, ne fait que **retrouver et citer** ce qui
  existe déjà dans les documents.
- **`DureeBudget`** : répartition automatique du temps de la séance entre
  les étapes du déroulement, proportionnellement à la durée choisie
  (toujours signalée comme une *proposition*, jamais une information
  extraite).
- **Écran "Génération rapide"** (section 23 du cahier des charges) :
  l'enseignant tape une ligne du type `6ème English - Greetings - 2 heures`,
  l'application identifie la classe, cherche dans les ressources déjà
  importées, et crée un brouillon de fiche pré-rempli — toujours modifiable
  ensuite dans le formulaire habituel.
- **Distinction extrait / proposition** (section 26) : le contenu généré
  précise `[Extrait de {document} — page {n}]` pour ce qui vient des
  documents, ou `(Proposition générée...)` quand rien n'a été trouvé.
- **Bloc "Sources"** dans le détail de la fiche : liste chaque citation
  (document, page, catégorie), consultable par l'enseignant (section 27).

Ce que fait *encore* le générateur V2 : il repère des extraits de texte
pertinents (par mots-clés) et les cite. Il ne "comprend" pas encore le
contenu pédagogique (il ne sait pas identifier tout seul le vocabulaire,
la grammaire ou des activités structurées dans un PDF) — c'est prévu pour
la suite du moteur, éventuellement avec le mode IA locale optionnel
(section 25 du cahier des charges).

## Ce qui n'est PAS encore dans le projet (prévu V2 suite / V3 / V4)

- Identification automatique des chapitres/leçons/exercices à l'intérieur
  d'un document (structure fine, au-delà de la simple page)
- Génération automatique du vocabulaire, de la grammaire, des activités et
  exercices différenciés (facile/moyen/avancé) à partir des sources
- Assistant pédagogique conversationnel / petit modèle de langage local
- Export DOCX, sauvegarde/restauration, statistiques de progression,
  multi-années scolaires, interface multilingue complète

## Nouveauté — contenus Anglais pré-chargés (T6 à T9)

Au tout premier lancement, l'application importe automatiquement, **pour
la matière Anglais et les 4 niveaux du collège (6ème/T6 à 3ème/T9)** :

- le **Programme d'Études** (PROGRAMME),
- la **Répartition Annuelle du Programme — RAPE** (REPARTITION),
- le **Fascicule de Ressources Pédagogiques — FRP** (FASCICULE),

extraits de vos propres documents et convertis en texte, avec découpage
en pages pour permettre des citations précises. Une classe par défaut est
créée pour chaque niveau ("6ème (English)", etc.).

L'application crée aussi automatiquement **28 fiches de préparation**
suivant l'ordre des unités du programme (7 pour la 6ème, 6 pour la 5ème,
7 pour la 4ème, 8 pour la 3ème) :
- **4 fiches entièrement rédigées** (une par niveau, sur la première unité
  réellement enseignée), avec vocabulaire, grammaire, activités et — pour
  la 6ème — un exercice complet avec corrigé, **directement tirés de vos
  documents et cités comme sources** ;
- les **autres fiches** sont créées à l'état "à faire", déjà titrées et
  numérotées selon la progression officielle, prêtes à être complétées.

Ce pré-remplissage ne se déclenche qu'une seule fois (un indicateur est
stocké localement) : si vous supprimez une ressource ou une fiche
générée, elle ne sera pas réimportée automatiquement au lancement
suivant.

**Non inclus, volontairement :** les manuels Bescherelle et Bled
(Hatier/Hachette) ne sont pas embarqués dans le code source — ce sont des
ouvrages publiés sous droit d'auteur, ce qui serait problématique dans un
dépôt (a fortiori public sur GitHub). Vous pouvez toujours les importer
vous-même, pour votre usage personnel, via "Mes ressources" sur votre
téléphone.



1. Installer **Android Studio** (Koala ou plus récent).
2. `Ouvrir un projet existant` → sélectionner le dossier
   `TeacherAssistantOffline/`.
3. Laisser Gradle synchroniser (ceci nécessite une connexion Internet **une
   seule fois**, pour télécharger les dépendances — c'est normal et ne
   contredit pas le cahier des charges : c'est l'usage quotidien de
   l'application, une fois installée sur le téléphone, qui doit être hors
   ligne, pas sa compilation).
4. Lancer sur un émulateur ou un téléphone Android (minSdk 24 — Android
   7.0 et plus).

## Architecture

```
app/src/main/java/com/fahendrena/teacherassistant/
├── data/            entités Room, DAO, base de données, dépôt (repository)
├── pdf/             extraction de texte PDF + export PDF de la fiche
├── search/          moteur de recherche locale
├── viewmodel/        AppViewModel (état de l'application)
├── ui/
│   ├── navigation/  graphe de navigation Compose
│   └── screens/     Home, Profil, Classes, Ressources, Recherche,
│                    Liste des préparations, Formulaire, Détail
└── MainActivity.kt
```

## Prochaine étape suggérée (V2)

Analyse des programmes/répartitions importés pour proposer automatiquement
un contenu de leçon (objectifs, vocabulaire, activités) à partir des
documents déjà présents dans "Mes ressources", avec citation de la source
(document + page).
